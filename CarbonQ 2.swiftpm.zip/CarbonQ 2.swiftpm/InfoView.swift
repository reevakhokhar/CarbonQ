import SwiftUI

struct InfoView: View {
    var body: some View {
        VStack {
            
            Text("🌱 About Carbon Emissions 🌱")
                .font(.custom("Comic Sans MS", size: 36))
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .padding()
            
            Text(" What Are Carbon Emissions? 💭")
                .font(.custom("Comic Sans MS", size: 26))
                .fontWeight(.bold)
                .padding(.horizontal)
                
            
            Text("Carbon emissions refer to the release of carbon dioxide (CO2) and other greenhouse gases into the atmosphere. These emissions primarily come from human activities such as burning fossil fuels for energy, transportation, industrial processes, and deforestation.")
                .font(.custom("Comic Sans MS", size: 20))
                .padding(.horizontal)
                .padding()
                .multilineTextAlignment(.center)
            
            Text(" Why Should We Be Concerned? 🤔")
                .font(.custom("Comic Sans MS", size: 26))
                .fontWeight(.bold)
                .padding(.horizontal)
            
            Text("Carbon emissions contribute to climate change by trapping heat in the Earth's atmosphere. They make the Earth warmer and cause what we commonly refer to as global warming. The increasing carbon emissions are responsible for many of the frequent and severe weather events happening around the world. They have also caused the sea levels to rise and disrupted habitats and ecosystems. Undoutedly, carbon emissions are a threat to animals, humans, and the entire planet. Addressing them is crucial for ensuring a sustainable future!")
                .font(.custom("Comic Sans MS", size: 20))
                .padding(.horizontal)
                .padding()
                .multilineTextAlignment(.center)
            
            Text(" What Can You Do About It? ♻️")
                .font(.custom("Comic Sans MS", size: 26))
                .fontWeight(.bold)
            
            Text("This is our planet and it is our responsibility to make it sustainable for the generations to come. Some actions you can take as an individual are reducing your energy consumption, transitioning to renewable energy sources, and practicing energy-efficient habits in your daily life. You can also start an eco-firendly business or be more environmentally conscious and support the eco-friendly brands out there. Furthermore, you can advocate for sustainability in your community and to your local government. You can also start investing in clean technologies, using more sustainable transportation options like walking, biking, carpooling, or using the public transport. The point is now that you know all about the importance of reducing carbon emissions you can help make a difference. You can raise awareness about them and work towards educating your friends and family about the importance of carbon emission reduction as well. Even small acts you do can help bring the change we need for this planet's brighter and sustainable future!")
                .font(.custom("Comic Sans MS", size: 20))
                .padding()
                .padding(.horizontal)
                .multilineTextAlignment(.center)
            
            Spacer()
        }
        .background(Color.yellow.opacity(0.2))
        Spacer()
        Spacer()

    }
}

struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView()
    }
}
