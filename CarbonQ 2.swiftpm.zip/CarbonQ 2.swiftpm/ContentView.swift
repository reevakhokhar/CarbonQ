import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                
                Spacer()
                
                Text(" 🌎🌲 CarbonQ 🌲🌎 ")
                    .font(.custom("Comic Sans MS", size: 40))
                    .multilineTextAlignment(.center)
                    .fontWeight(.bold)
                    .padding()
                    .padding()
                       
                NavigationLink(destination: InfoView()) {
                    Text("About Carbon Emissions")
                        .font(.custom("Comic Sans MS", size: 26))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green.opacity(0.6))
                        .cornerRadius(10)
                        .padding(.horizontal, 50) 
                }
                
                NavigationLink(destination: FactsView()) {
                    Text("Learn An Interesting Fun Fact")
                        .font(.custom("Comic Sans MS", size: 26))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green.opacity(0.8))
                        .cornerRadius(10)
                        .padding(.horizontal, 50)  
                }
                
                NavigationLink(destination: QuizView()) {
                    Text("Calculate Your Carbon Footprint")
                        .font(.custom("Comic Sans MS", size: 26))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10);
                }
                
                Spacer() 
            }
            .padding()
            .background(Color(red: 230/255, green: 255/255, blue: 192/255))
            .edgesIgnoringSafeArea(.all)
            .navigationBarTitle("", displayMode: .inline) 
        }
        .navigationViewStyle(StackNavigationViewStyle()) 
    }
}
