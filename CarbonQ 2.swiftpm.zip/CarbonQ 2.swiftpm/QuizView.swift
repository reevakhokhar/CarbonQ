import SwiftUI

//structure for quiz question and answer

struct CarbonQuizQuestion {
    let text: String
    let answers: [String]
    let pointValues: [Int]
    let correctAnswerIndex: Int
}

struct QuizView: View {
    
    @State private var currentQuestionIndex = 0
    @State private var selectedAnswerIndex = 0  
    @State private var totalPoints = 0  
    @State private var showResult = false  
    
    //NOTE: the lower the carbon footprint the better; That's why in this program lower point values are assigned to the better answers 
    
    let questions: [CarbonQuizQuestion] = [
        CarbonQuizQuestion(
            text: "What means of transportation do you use most?",
            answers: ["Walking or biking", "Public Transport (trains or bus)", "Car or Motorcycle"],
            pointValues: [1, 3, 5], // more greener option is better
            correctAnswerIndex: 1 // correct answer index
        ),
        CarbonQuizQuestion(
            text: "How often do you consume meat-based products?",
            answers: ["Always (Meat lover for life)", "Occasionally (I like to mix it up)", "Never (Go plant-power)"],
            pointValues: [5, 3, 1], // less meat consumption is better for reducing carbon emissions
            correctAnswerIndex: 2 // correct answer index
        ),
        CarbonQuizQuestion(
            text: "How often do you practice energy-saving habits at home?",
            answers: ["All the time", "Sometimes", "Never"],
            pointValues: [1, 3, 5], // the more energy-saving habits practiced the betert
            correctAnswerIndex: 0 // correct answer index
        ),
        CarbonQuizQuestion(
            text: "How often do you purchase new items rather than opting for used or second-hand goods?",
            answers: ["Always buy new", "A balance of new and used", "Always buy used"],
            pointValues: [5, 3, 1], // more second-hand purchases are better
            correctAnswerIndex: 2 // correct answer index
        ),
        CarbonQuizQuestion(
            text: "How often do you participate in activities that involve air travel?",
            answers: ["Never", "Rarely (I fly on rare occasions once or twice a year)", "Occasionally (I fly several times a year)", "Frequently (I fly a lot every month)", "Very Frequently (I practically live at the airport and fly a lot weekly)"],
            pointValues: [1, 2, 3, 4, 5], // less air travel is good for carbon emissions
            correctAnswerIndex: 0 // correct answer index
        ),
        CarbonQuizQuestion(
            text: "How often do you recycle materials such as paper, plastic, glass, and metal?",
            answers: ["Never", "Sometimes (Whenever I remember)", "Always (Reduce, reuse, recycle is my motto)"],
            pointValues: [5, 3, 1], // recyclcing is always a good practice for reducing carbon emissions
            correctAnswerIndex: 2 // correct answer index
        )
    ]
    
    var body: some View {
        ZStack {
            Spacer()
            Spacer()
            .padding()
            Color.yellow.opacity(0.2) // BG - lighter shade of yellow
            
            VStack {
                Spacer() // passion about title
                Text("🌱 Carbon Footprint Calculator 🌱")
                    .font(.custom("Comic Sans MS", size: 36))
                    .fontWeight(.bold)
                    .padding()
                    .multilineTextAlignment(.center)
                   
                if currentQuestionIndex < questions.count {
                    QuestionView(question: questions[currentQuestionIndex], selectedAnswerIndex: $selectedAnswerIndex, totalPoints: $totalPoints, currentQuestionIndex: $currentQuestionIndex)
                        .padding()
                } else {
                    let (carbonFootprint, message) = calculateCarbonFootprint()
                    ResultView(carbonFootprint: carbonFootprint, message: message)
                        .padding()
                    
                    NavigationLink(
                        destination: InfoView(),
                        label: {
                            Text("Learn More")
                                .padding()
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .padding(50)
                        })
                }
                
                Spacer()
            }
        }
        .font(.custom("Comic Sans MS", size: 16))
    }
    
    func calculateCarbonFootprint() -> (String, String) {
       
        //  carbon footprint calculation based on answers and their correlating points 
        let averagePoints = Int(totalPoints) / Int(questions.count)
        var carbonFootprint = ""
        var message = ""
        
        switch averagePoints {
        case 7..<15:
            carbonFootprint = "😢 Your carboon footprint is currently really bad! 😢"
            message = "That's ok though, taking the effort to understand where you are going wrong is a very good start! Now that you know it's time to take action and make some changes to reduce your impact on the environment. Start by cutting down on your energy usage, recycling more, and choosing more eco-friendly alternatives whenever possible. You can do it!"
        case 4..<6:
            carbonFootprint = "😞 Your carbon footprint needs a little improvement. 😞"
            message = " You are making some really good choices, and some that are harming the environment. Don't worry, though! You just need to make a few adjustments to your lifestyle. Try to be more mindful about your energy consumption, try to use public transport more, and always make sure to recycle. Even a small change can have a grand effect!"
        case 2..<3:
            carbonFootprint = "🙂 You are on track! 🙂"
            message = "You're doing great, but as they say there is always room for improvement. To reduce your carbon footprint even further, focus on conserving energy, reducing waste, and making more eco-friendly choices in your daily life. Keep up the effort, and you can become an eco-champion very soon!"
        case 0..<1:
            carbonFootprint = "😊 Your carbon footprint shows you are doing really well! 😊"
            message = "You're making a positive impact on the environment with your consistent eco-friendly choices! Keep up the good work and continue recycling, conserving energy, and supporting sustainable practices and eco-friendly brands. The planet appreciates you!"
        default:
            carbonFootprint = "😎 Your carbon footprint shows you are an Eco-Champion! 😎"
            message = "Wow, you're a carbon footprint superstar! Your dedication to the environment is inspiring. Keep spreading awareness, making sustainable choices, and encouraging others to do the same. Together, we can make a difference!"
        }
        
        return (carbonFootprint, message)
    }
}

struct QuestionView: View {
    let question: CarbonQuizQuestion
    @Binding var selectedAnswerIndex: Int
    @Binding var totalPoints: Int
    @Binding var currentQuestionIndex: Int
    
    var body: some View {
        VStack {
            Text(question.text)
                .font(.custom("Comic Sans MS", size: 18))
                .padding()
            
            ForEach(question.answers.indices, id: \.self) { answerIndex in
                let answer = question.answers[answerIndex]
                let is_answer_selected = answerIndex == selectedAnswerIndex
                
                let action = {
                    selectedAnswerIndex = answerIndex
                    totalPoints += question.pointValues[answerIndex] // add to total points
                }
                
                Button(action: action) {
                    AnswerButton(text: answer, isSelected: is_answer_selected)
                }
                .padding(.vertical, 6) //for in between
                .cornerRadius(10)
                .shadow(radius: 0) // no shadow
            }
            
            Button("Next Question") { // Green bg
                currentQuestionIndex += 1
                selectedAnswerIndex = 0
            }
            .padding()
            .background(Color.green)
            .foregroundColor(.white)
            .cornerRadius(10)
            .padding(50)  
        }
    }
}
struct AnswerButton: View {
    let text: String
    let isSelected: Bool
    
    var body: some View {
        if isSelected {
            return Text(text)
                .padding()
                .foregroundColor(.black)
                .background(Color.green.opacity(0.35)) // Lighter green bg selected
        } else {
            return Text(text)
                .padding()
                .foregroundColor(.black)
                .background(Color.white) // White bg for unselected
        }
    }
}

struct ResultView: View {
    let carbonFootprint: String
    let message: String
    
    var body: some View {
        VStack {
            Text("Quiz Completed...")
                .font(.custom("Comic Sans MS", size: 30))
                .padding()
            
            Text("According to your results:")
                .font(.custom("Comic Sans MS", size: 26))
            
            Text(carbonFootprint)
                .font(.custom("Comic Sans MS", size: 26))
                .fontWeight(.bold)
                .multilineTextAlignment(.center) 
            
            Text(message)
                .font(.custom("Comic Sans MS", size: 23))
                .padding()
                .multilineTextAlignment(.center)  
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        QuizView()
    }
}
