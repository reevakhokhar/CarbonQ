import SwiftUI

struct FactsView: View {
    //Sources for facts:
    // https://www.ecotricity.co.uk/our-news/2017/six-scary-facts-about-climate-change 
    // https://www.conserve-energy-future.com/various-climate-change-facts-php.php
    // https://www.americansecurityproject.org/
    // https://www.ifaw.org/journal/animals-most-impacted-climate-change
    
    let facts_collection: [String] = [
        "1/2 of the world's coral reefs have died in the past 20 years. ",
        "Earth is now warmer than it has been in the past 800,000 years. ",
        "Climate change is causing large-scale migration. Reports predict that by 2050 more than 200 million people can be displaced as a result of climate change.",
        "The burning of fossil fuels like coal, oil, and natural gas is the largest contributor to human-caused climate change.",
        "According to the World Food Program (WPF.org) by 2030, the number of people affected by climate change disasters could reach 375 million per year.",
        "Over the last 50 years, the concentration of carbon dioxide in the atmosphere has increased by 30%.",
        "Climate change causes the death of more than 400,000 people each year.",
        "According to the International Fund for Animal Welfare 18% of all land species can go extinct beacuse of climate change in the near future",
        "More than 10,900 species on the IUCN Red List are affected by climate change."
    ]    
    
    @State private var fact = ""
    var body: some View {        
        ZStack {
            Color.yellow.opacity(0.2)
            VStack {
                Text("🪴🌱 Climate Change Facts 🌱🪴")
                    .fontWeight(.bold)
                    .font(.custom("Comic Sans MS", size: 40))
                    .foregroundColor(Color.black)
                    .padding()
                    .cornerRadius(10)
                    .multilineTextAlignment(.center)
                
                Text(fact)
                    .padding()
                    .font(.custom("Comic Sans MS", size: 26))
                    .frame(minHeight: 300)
                    .multilineTextAlignment(.center)
                    .cornerRadius(10)
                
                Button(action: {
                    fact = facts_collection.randomElement()!
                }) {
                    Text("Click here to learn an interesting fact about climate change!")
                        .foregroundColor(Color.white)
                        .font(.custom("Comic Sans MS", size: 26))
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10)
                }
                .padding()
            }
        }

    }
}

struct FactsView_Previews: PreviewProvider {
    static var previews: some View {
        FactsView()
    }
}
